﻿using Swift.DAL.OnlineAgent;
using Swift.DAL.SwiftDAL;
using Swift.web.Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Swift.web.Remit.Administration.OnlineCustomer
{
	public partial class Detail : System.Web.UI.Page
	{
		private readonly RemittanceLibrary _sl = new RemittanceLibrary();
		private readonly OnlineCustomerDao _cd = new OnlineCustomerDao();
		private const string ViewFunctionId = "20130000";
		string m = GetStatic.ReadQueryString("m", "");
		string id = GetStatic.ReadQueryString("customerId", "");
		protected void Page_Load(object sender, EventArgs e)
		{
			_sl.CheckSession();
			btnApprove.Visible = false;
			if (!IsPostBack)
			{
				Authenticate();
				
				if (id != "")
				{
					if (m != "")
					{
						btnApprove.Visible = true;
					}
					PopulateCustomerDetails(id);
				}
			}
		}

		private void Authenticate()
		{
			_sl.CheckAuthentication(ViewFunctionId);
		}

		private void PopulateCustomerDetails(string id)
		{
			var dr = _cd.GetVerifyCustomerDetails(id, GetStatic.GetUser());
			hdnCustomerId.Value = dr["customerId"].ToString();
			fullName.Text = dr["fullName"].ToString();
			genderList.Text = dr["gender"].ToString();
			countryList.Text = dr["country"].ToString();
			addressLine1.Text = dr["address"].ToString();
			postalCode.Text = dr["postalCode"].ToString();
			city.Text = dr["city"].ToString();
			email.Text = dr["email"].ToString();
			phoneNumber.Text = dr["homePhone"].ToString();
			mobile.Text = dr["mobile"].ToString();
			nativeCountry.Text = dr["nativeCountry"].ToString();
			dob.Text = dr["dob"].ToString();
			occupation.Text = dr["occupation"].ToString();
			IssueDate.Text = dr["idIssueDate"].ToString();
			ExpireDate.Text = dr["idExpiryDate"].ToString();
			idType.Text = dr["idType"].ToString();
			verificationTypeNo.Text = dr["idNumber"].ToString();

            if (dr["verifyDoc1"].ToString() != "")
                verfDoc1.ImageUrl = "GetDocumentView.ashx?imageName=" + dr["verifyDoc1"] + "&mobileNo=" + dr["mobile"];
            if (dr["verifyDoc2"].ToString() != "")
                verfDoc2.ImageUrl = "GetDocumentView.ashx?imageName=" + dr["verifyDoc2"] + "&mobileNo=" + dr["mobile"];
            if (dr["verifyDoc3"].ToString() != "")
                verfDoc3.ImageUrl = "GetDocumentView.ashx?imageName=" + dr["verifyDoc3"] + "&mobileNo=" + dr["mobile"];
		}

		protected void approve_Click(object sender, EventArgs e)
		{
			if(m=="ap")
			{
				var dbResult= _cd.ApprovePending(id, GetStatic.GetUser());
                if (dbResult.Tables.Count == 2)
                {
                    if (dbResult.Tables[1].Rows[0]["ErrorCode"].Equals("0"))
                    {
                        if (dbResult.Tables[0].Rows[0]["username"] != null)
                        {
                            string channel = dbResult.Tables[0].Rows[0]["channel"].ToString();
                            string username = dbResult.Tables[0].Rows[0]["username"].ToString();
                            string pwd = dbResult.Tables[0].Rows[0]["password"].ToString();
                            string account = dbResult.Tables[0].Rows[0]["account"].ToString();

                            string msgBody = GetApprovedCustomerMsgBody(channel, username, pwd, account);
                            string msgSubject = "Customer verification approved";
                            Task.Factory.StartNew(() =>
                            {
                                SendEmail(msgSubject, msgBody, username);
                            });
                        }
                        GetStatic.SetMessage(dbResult.Tables[1].Rows[0]["ErrorCode"].ToString(), dbResult.Tables[1].Rows[0]["Msg"].ToString());
                        Response.Redirect("ApprovedList.aspx");
                    }
                }

               GetStatic.AlertMessage(Page, dbResult.Tables[0].Rows[0]["msg"].ToString());
			}
			else if(m=="vp")
			{
				var dbResult = _cd.VerifyPending(id, GetStatic.GetUser());
                if (dbResult.ErrorCode.Equals("0"))
                {
                    GetStatic.SetMessage(dbResult);
                    Response.Redirect("List.aspx");
                }

                GetStatic.AlertMessage(Page, dbResult.Msg);

			}
		}

        private void SendEmail(string msgSubject, string msgBody, string toEmailId)
        {
            string sendEmailId=GetStatic.GetSendEmailId();
            string sendEmailPwd=GetStatic.GetSendEmailPwd();
            int smtpPort=Convert.ToInt32(GetStatic.GetSmtpPort());
            string smtpServer=GetStatic.GetSmtpServer();
            bool enableSsl=true;
            
            SmtpMailSetting mail = new SmtpMailSetting
            {
                SendEmailId = sendEmailId,
                MsgBody=msgBody,
                MsgSubject=msgSubject,
                ToEmails=toEmailId,
                EnableSsl=enableSsl,
                SendEmailPwd=sendEmailPwd,
                SmtpPort=smtpPort,
                SmtpServer=smtpServer
                        
            };

            mail.SendSmtpMail(mail);
        }

        public string GetApprovedCustomerMsgBody(string channel,string username,string pwd,string account)
        {
            var mailBody = "Dear Mr./Ms./Mrs. " + fullName.Text + ",";
            if (channel == "online")
            {

                mailBody +=
                    "<br><br>Thank you for registering with GME Online Remittance.";
            }
            else
            {
                mailBody +=
                    "<br><br>Thank you for registering with GME Online Remittance. Please find your username below:";
                mailBody += "<br><br>Username: " + username;
                mailBody += "<br>Password: " + pwd;

            }
            mailBody +=
                "<br><br>Your login with GMERemit is checked and validated. You can now start sending remittance to your desired country.";
            mailBody +=
                "<br><br><br>PROCESS TO TRANSFER FUNDS:";
            mailBody += "<br>• Your unique account number with GME is "+account+", it is displayed in your login window all the time";
             mailBody += "<br>• Please make your desired transfer in your GME account through your nearest ATM or ebanking";
             mailBody += "<br>• Login to <a href=\"http://www.gmeremit.com\"> www.gmeremit.com </a> and click send money. Please enter your beneficiary details to transfer funds";
             mailBody += "<br>• For cash transfers, you will receive a PIN Code after successfully submitting your details. For account transfers to your desired country, GME will process the transactions to be deposited within 24 hours (deposit time may vary where beneficiary banks are not easily accessible)";
             mailBody += "<br>• All cash transfers has to be verified by GME and are ready to collect at your location within an hour";

             mailBody += "<br><br>Note: *All Receipts generated after successful transfers are also sent to your registered email.";
             mailBody += "<br><br><br>*Money transfer limit per transaction is USD 3,000 and USD 20,000 for 1 year.";
            mailBody +=
                "<br><br>If you need further assistance kindly reply this email or call us at 02-3673-5559. or visit our website <a href=\"http://www.gmeremit.com\"> www.gmeremit.com </a>";
            mailBody +=
                "<br><br><br>We look forward to provide you excellent service.";
            mailBody +=
               "<br><br>Thank You.";
            mailBody +=
               "<br><br><br>Regards,";
            mailBody +=
               "<br>GME Online Team";
            mailBody +=
               "<br>Head Office";
            mailBody +=
               "<br>325, Jong-ro, ";
            mailBody +=
               "<br>Jongno-gu, 03104 Seoul, Korea "; 
            mailBody +=
               "<br>Phone number 02-3673-5559 "; 
             return mailBody;
        }
	}
}