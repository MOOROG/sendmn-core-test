﻿using System.Web;
using Swift.web.Library;

namespace Swift.web.Remit.Administration.OnlineCustomer
{
	/// <summary>
	/// Summary description for VerifyDocuments
	/// </summary>
	public class GetDocumentView : IHttpHandler
	{

		public void ProcessRequest(HttpContext context)
		{
			var imageName = context.Request.QueryString["imageName"];
			var mobileNo = context.Request.QueryString["mobileNo"];
			var file = GetStatic.GetAppRoot() + "CustomerDocument\\" + mobileNo + "\\" + imageName;
			context.Response.ContentType = "image/jpg";
			context.Response.WriteFile(file);
		}

		public bool IsReusable
		{
			get
			{
				return false;
			}
		}
	}
}