﻿using Swift.web.Library;
using System;
using System.Configuration;
using System.IO;
using System.Web.UI.WebControls;
using Swift.DAL.OnlineAgent;

namespace Swift.web.Remit.Administration.OnlineCustomer
{
	public partial class Manage : System.Web.UI.Page
	{
		private readonly RemittanceLibrary _sl = new RemittanceLibrary();
		private readonly OnlineCustomerDao _cd=new OnlineCustomerDao();
        private const string ViewFunctionId = "20130000";
		protected void Page_Load(object sender, EventArgs e)
		{
			_sl.CheckSession();
			if (!IsPostBack)
			{
				Authenticate();
				PopulateDdl();
				string eId = GetStatic.ReadQueryString("id", "");
				if (eId != "")
					PopulateForm(eId);
			}
		}

        private void PopulateForm(string eId)
        {
            var dr = _cd.GetCustomerDetails(eId, GetStatic.GetUser());
            if (null != dr)
            {
                hdnCustomerId.Value = dr["customerId"].ToString();
                firstName.Text = dr["firstName"].ToString();
                middleName.Text = dr["middleName"].ToString();
                lastName.Text = dr["lastName1"].ToString();
                genderList.SelectedValue = dr["gender"].ToString();
                countryList.Text = dr["country"].ToString();
                addressLine1.Text = dr["address"].ToString();
                postalCode.Text = dr["postalCode"].ToString();
                city.Text = dr["city"].ToString();
                email.Text = dr["email"].ToString();
                emailConfirm.Text = dr["email"].ToString();
                phoneNumber.Text = dr["telNo"].ToString();
                mobile.Text = dr["mobile"].ToString();
                nativeCountry.SelectedValue = dr["nativeCountry"].ToString();
                dob.Text = dr["dob"].ToString();
                occupation.Text = dr["occupation"].ToString();
                IssueDate.Text = dr["idIssueDate"].ToString();
                ExpireDate.Text = dr["idExpiryDate"].ToString();

                idType.Text = dr["idType"].ToString();
                verificationTypeNo.Text = dr["idNumber"].ToString();
                if (dr["verifyDoc1"].ToString() != "")
                    verfDoc1.ImageUrl = "GetDocumentView.ashx?imageName=" + dr["verifyDoc1"] + "&mobileNo=" + dr["mobile"];
                if (dr["verifyDoc2"].ToString() != "")
                    verfDoc2.ImageUrl = "GetDocumentView.ashx?imageName=" + dr["verifyDoc2"] + "&mobileNo=" + dr["mobile"];
                if (dr["verifyDoc3"].ToString() != "")
                    verfDoc3.ImageUrl = "GetDocumentView.ashx?imageName=" + dr["verifyDoc3"] + "&mobileNo=" + dr["mobile"];

                hdnVerifyDoc1.Value = dr["verifyDoc1"].ToString();
                hdnVerifyDoc2.Value = dr["verifyDoc2"].ToString();
                hdnVerifyDoc3.Value = dr["verifyDoc3"].ToString();

                email.ReadOnly = true;
                emailConfirm.ReadOnly = true;
                mobile.ReadOnly = true;
            }

        }

        private void Authenticate()
        {
            _sl.CheckAuthentication(ViewFunctionId);
        }

        private void PopulateDdl()
        {
            _sl.SetDDL(ref genderList, "EXEC proc_online_dropDownList @flag='GenderList'", "valueId", "detailTitle", "", "Select..");
            _sl.SetDDL(ref countryList, "EXEC proc_online_dropDownList @flag='onlineCountrylist'", "countryId", "countryName", "", "Select..");
            _sl.SetDDL(ref nativeCountry, "EXEC proc_online_dropDownList @flag='allCountrylist'", "countryId", "countryName", "", "Select..");
            _sl.SetDDL(ref occupation, "EXEC proc_online_dropDownList @flag='occupationList'", "valueId", "detailTitle", "", "Select..");
            _sl.SetDDL(ref idType, "EXEC proc_online_dropDownList @flag='idType'", "valueId", "detailTitle", "", "Select..");


        }

        protected void register_Click(object sender, EventArgs e)
        {

            if (email.Text.Equals(emailConfirm.Text))
            {
                string verDoc1 = UploadDocument(VerificationDoc1, mobile.Text);
                string verDoc2 = UploadDocument(VerificationDoc2, mobile.Text);
                string verDoc3 = UploadDocument(VerificationDoc3, mobile.Text);
                OnlineCustomerModel customerModel = new OnlineCustomerModel()
                {
                    flag = "customer-register-core"
                    ,
                    firstName = firstName.Text
                    ,
                    middleName = middleName.Text
                    ,
                    lastName1 = lastName.Text
                    ,
                    gender = genderList.SelectedValue
                    ,
                    country = countryList.Text
                    ,
                    address = addressLine1.Text
                    ,
                    zipCode = postalCode.Text
                    ,
                    city = city.Text
                    ,
                    email = email.Text
                    ,
                    homePhone = phoneNumber.Text
                    ,
                    mobile = mobile.Text
                    ,
                    nativeCountry = nativeCountry.SelectedValue
                    ,
                    dob = dob.Text
                    ,
                    occupation = occupation.Text
                    ,
                    postalCode = postalCode.Text
                    ,
                    idIssueDate = IssueDate.Text
                    ,
                    idExpiryDate = ExpireDate.Text
                    ,
                    idType = idType.Text
                    ,
                    idNumber = verificationTypeNo.Text
                    ,
                    telNo = phoneNumber.Text
                    ,
                    ipAddress = GetStatic.GetIp()
                    ,
                    createdBy = GetStatic.GetUser()
                    ,
                    verifyDoc1 = verDoc1
                    ,
                    verifyDoc2 = verDoc2
                    ,
                    verifyDoc3 = verDoc3
                };

                if (hdnCustomerId.Value != "")
                {
                    customerModel.customerId = hdnCustomerId.Value;
                    customerModel.flag = "customer-update-core";
                    if (verDoc1 == "")
                        customerModel.verifyDoc1 = hdnVerifyDoc1.Value;
                    if (verDoc2 == "")
                        customerModel.verifyDoc2 = hdnVerifyDoc2.Value;
                    if (verDoc3 == "")
                        customerModel.verifyDoc3 = hdnVerifyDoc3.Value;
                }

                var dbResult = _cd.RegisterCustomer(customerModel);
                if (dbResult.ErrorCode == "0")
                {
                    GetStatic.SetMessage(dbResult);
                    Response.Redirect("VerifyPendingList.aspx");
                    return;
                }
                else
                {
                    GetStatic.AlertMessage(this, dbResult.Msg);
                    return;
                }
            }
        }


		private string UploadDocument(FileUpload doc,string customerId)
		{
			string fName = "";
			try
            {
				var fileType = doc.PostedFile.ContentType;
				if (fileType == "image/jpeg" || fileType == "image/png")
                {
					string extension = Path.GetExtension(doc.PostedFile.FileName);
					string fileName = customerId + "_" + GetTimestamp(DateTime.Now) + extension;
					string path = GetStatic.GetAppRoot() + "CustomerDocument\\" + customerId;
					if (!Directory.Exists(path))
						Directory.CreateDirectory(path);
					doc.SaveAs(path + "/" + fileName);
					fName = fileName; 
                }
                else
                {
					fName = "";
                }
            }
			catch (Exception ex)
			{
				fName = "";
			}
			return fName;
		}

		public static string GetTimestamp(DateTime value)
		{
			return value.ToString("hhmmssffffff");
		}
	}
}